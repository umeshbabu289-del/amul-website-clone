# Amul Clone - Full Stack Web Application

A complete clone of the Amul dairy company website built with Flask, HTML, CSS, JavaScript, and JSON file storage.

## Features

### Frontend
- **Responsive Design**: Mobile-first approach with vibrant Amul-inspired colors
- **Interactive Homepage**: Hero slider, product showcases, news updates
- **Product Catalog**: Filterable products with categories, search functionality
- **News System**: Latest updates with category filtering
- **Location Finder**: Search Amul centers and parlours
- **Contact System**: Contact form with validation

### Backend
- **Flask API**: RESTful endpoints for all data operations
- **JSON Storage**: Products, news, categories, locations, contact inquiries stored in JSON files
- **Search Functionality**: Global search across products and news
- **Admin Features**: Product and news management

### Interactive Features
- **Shopping Cart**: Add/remove products with localStorage persistence
- **Favorites System**: Save favorite products
- **Quick View**: Product details in modal popup
- **Real-time Search**: Instant search with API integration
- **Notifications**: Toast notifications for user actions
- **Lazy Loading**: Optimized image loading
- **Scroll Animations**: Smooth animations on scroll

## Technology Stack

- **Backend**: Python Flask
- **Storage**: JSON files (no database required)
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Custom CSS with Flexbox/Grid
- **Icons**: Font Awesome
- **Client Storage**: localStorage for cart and favorites

## Installation

1. **Clone the repository**
   \`\`\`bash
   git clone <repository-url>
   cd amul-clone
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

3. **Run the application**
   \`\`\`bash
   python app.py
   \`\`\`
   The application will automatically create the necessary data files on first run.

4. **Access the website**
   Open http://localhost:5000 in your browser

## Project Structure

\`\`\`
amul-clone/
├── app.py                 # Main Flask application
├── data_manager.py        # JSON data management system
├── api/
│   └── routes.py         # API endpoints
├── data/                 # JSON data files (auto-created)
│   ├── products.json
│   ├── categories.json
│   ├── news.json
│   ├── locations.json
│   └── contact_inquiries.json
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── products.html
│   ├── news.html
│   ├── locations.html
│   ├── contact.html
│   └── search.html
├── static/
│   ├── css/             # Stylesheets
│   ├── js/              # JavaScript files
│   └── images/          # Static images
└── requirements.txt
\`\`\`

## API Endpoints

### Products
- `GET /api/products` - Get all products
- `GET /api/products/<id>` - Get single product
- `POST /api/products` - Create product (admin)

### Categories
- `GET /api/categories` - Get all categories

### News
- `GET /api/news` - Get all news
- `GET /api/news/<id>` - Get single news item

### Locations
- `GET /api/locations` - Get all locations

### Contact
- `POST /api/contact` - Submit contact form
- `GET /api/contact` - Get inquiries (admin)

### Search
- `GET /api/search?q=<query>` - Global search

### Statistics
- `GET /api/stats` - Get website statistics

## Data Structure

### Products (data/products.json)
\`\`\`json
{
  "id": 1,
  "name": "Product Name",
  "category": "milk",
  "description": "Product description",
  "price": 99.99,
  "image_url": "/placeholder.svg",
  "is_featured": true,
  "created_at": "2024-01-01T00:00:00"
}
\`\`\`

### News (data/news.json)
\`\`\`json
{
  "id": 1,
  "title": "News Title",
  "content": "News content...",
  "image_url": "/placeholder.svg",
  "category": "company",
  "is_featured": true,
  "published_at": "2024-01-01T00:00:00"
}
\`\`\`

### Categories (data/categories.json)
\`\`\`json
{
  "id": 1,
  "name": "Milk",
  "slug": "milk",
  "description": "Fresh dairy milk products",
  "display_order": 1
}
\`\`\`

### Locations (data/locations.json)
\`\`\`json
{
  "id": 1,
  "name": "Amul Dairy - Anand",
  "address": "Amul Dairy Road, Anand",
  "city": "Anand",
  "state": "Gujarat",
  "pincode": "388001",
  "phone": "+91-2692-260148",
  "email": "anand@amul.coop"
}
\`\`\`

### Contact Inquiries (data/contact_inquiries.json)
\`\`\`json
{
  "id": 1,
  "name": "Customer Name",
  "email": "customer@email.com",
  "phone": "+91-9876543210",
  "subject": "Inquiry Subject",
  "message": "Customer message...",
  "status": "pending",
  "created_at": "2024-01-01T00:00:00"
}
\`\`\`

## Features Implementation

### Shopping Cart
- Persistent storage using localStorage
- Add/remove/update quantities
- Cart counter in header
- Animated cart icon on add

### Search System
- Global search across products and news
- Real-time search suggestions
- Search results page with filtering
- API-powered search with pagination

### Interactive Elements
- Product quick view modals
- Favorite products system
- News category filtering
- Location search and filtering
- Smooth scroll animations
- Lazy loading for images

### Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Touch-friendly interactions
- Optimized for all screen sizes

## Data Management

The application uses a custom `DataManager` class that handles all data operations:

- **Automatic Initialization**: Creates sample data on first run
- **JSON Storage**: All data stored in human-readable JSON files
- **CRUD Operations**: Full create, read, update, delete functionality
- **Search & Filtering**: Advanced search and filtering capabilities
- **Statistics**: Real-time statistics generation

### Adding New Data

#### Adding Products
\`\`\`python
from data_manager import DataManager

dm = DataManager()
product_data = {
    'name': 'New Product',
    'category': 'milk',
    'description': 'Product description',
    'price': 99.99,
    'image_url': '/images/product.jpg',
    'is_featured': False
}
dm.create_product(product_data)
\`\`\`

#### Adding News
Edit `data/news.json` directly or use the API endpoint.

## Customization

### Colors
The color scheme follows Amul's brand colors:
- Primary: #dc3545 (Red)
- Secondary: #007bff (Blue)
- Success: #28a745 (Green)
- Warning: #ffc107 (Yellow)
- Info: #17a2b8 (Cyan)

### Data Customization
All data can be customized by editing the JSON files in the `data/` directory. The application will automatically load the updated data.

## Performance Optimizations

- Lazy loading for images
- Efficient JSON file operations
- Minified CSS and JavaScript
- Optimized image sizes
- Caching for static assets
- In-memory data caching

## Advantages of JSON Storage

- **No Database Setup**: No need to install or configure a database
- **Human Readable**: Data files can be easily viewed and edited
- **Version Control Friendly**: JSON files work well with Git
- **Portable**: Easy to backup and transfer data
- **Fast Development**: Quick to set up and modify

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational purposes only. Amul is a registered trademark of Gujarat Cooperative Milk Marketing Federation Ltd.
\`\`\`

```typescriptreact file="scripts/01_create_tables.sql" isDeleted="true"
...deleted...
