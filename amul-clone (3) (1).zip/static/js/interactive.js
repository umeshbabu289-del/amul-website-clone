// Interactive features for Amul clone

class AmulApp {
  constructor() {
    this.cart = JSON.parse(localStorage.getItem("amul_cart") || "[]")
    this.favorites = JSON.parse(localStorage.getItem("amul_favorites") || "[]")
    this.init()
  }

  init() {
    this.setupEventListeners()
    this.updateCartCounter()
    this.setupLazyLoading()
    this.setupScrollAnimations()
    this.setupNewsFiltering()
    this.setupLocationSearch()
  }

  setupEventListeners() {
    // Global search functionality
    document.addEventListener("keydown", (e) => {
      if (e.ctrlKey && e.key === "k") {
        e.preventDefault()
        this.focusSearch()
      }
    })

    // Newsletter subscription
    const newsletterForms = document.querySelectorAll(".newsletter-form")
    newsletterForms.forEach((form) => {
      form.addEventListener("submit", (e) => this.handleNewsletterSubscription(e))
    })

    // Product quick view
    const productCards = document.querySelectorAll(".product-card")
    productCards.forEach((card) => {
      const quickViewBtn = card.querySelector(".quick-view-btn")
      if (quickViewBtn) {
        quickViewBtn.addEventListener("click", (e) => {
          e.stopPropagation()
          this.showProductQuickView(card.dataset.productId)
        })
      }
    })

    // Favorite toggle
    const favoriteButtons = document.querySelectorAll(".favorite-btn")
    favoriteButtons.forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation()
        this.toggleFavorite(btn.dataset.productId)
      })
    })
  }

  // Cart functionality
  addToCart(productId, quantity = 1) {
    const existingItem = this.cart.find((item) => item.id === productId)

    if (existingItem) {
      existingItem.quantity += quantity
    } else {
      this.cart.push({
        id: productId,
        quantity: quantity,
        addedAt: new Date().toISOString(),
      })
    }

    this.saveCart()
    this.updateCartCounter()
    this.showNotification("Product added to cart!", "success")
    this.animateCartIcon()
  }

  removeFromCart(productId) {
    this.cart = this.cart.filter((item) => item.id !== productId)
    this.saveCart()
    this.updateCartCounter()
    this.showNotification("Product removed from cart", "info")
  }

  updateCartQuantity(productId, quantity) {
    const item = this.cart.find((item) => item.id === productId)
    if (item) {
      if (quantity <= 0) {
        this.removeFromCart(productId)
      } else {
        item.quantity = quantity
        this.saveCart()
        this.updateCartCounter()
      }
    }
  }

  saveCart() {
    localStorage.setItem("amul_cart", JSON.stringify(this.cart))
  }

  updateCartCounter() {
    const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0)
    const cartCounters = document.querySelectorAll(".cart-counter")

    cartCounters.forEach((counter) => {
      counter.textContent = totalItems
      counter.style.display = totalItems > 0 ? "block" : "none"
    })
  }

  animateCartIcon() {
    const cartIcon = document.querySelector(".cart-icon")
    if (cartIcon) {
      cartIcon.classList.add("cart-bounce")
      setTimeout(() => cartIcon.classList.remove("cart-bounce"), 600)
    }
  }

  // Favorites functionality
  toggleFavorite(productId) {
    const index = this.favorites.indexOf(productId)

    if (index > -1) {
      this.favorites.splice(index, 1)
      this.showNotification("Removed from favorites", "info")
    } else {
      this.favorites.push(productId)
      this.showNotification("Added to favorites!", "success")
    }

    this.saveFavorites()
    this.updateFavoriteButtons()
  }

  saveFavorites() {
    localStorage.setItem("amul_favorites", JSON.stringify(this.favorites))
  }

  updateFavoriteButtons() {
    const favoriteButtons = document.querySelectorAll(".favorite-btn")
    favoriteButtons.forEach((btn) => {
      const productId = btn.dataset.productId
      const isFavorite = this.favorites.includes(productId)

      btn.classList.toggle("active", isFavorite)
      btn.innerHTML = isFavorite ? '<i class="fas fa-heart"></i>' : '<i class="far fa-heart"></i>'
    })
  }

  // Search functionality
  focusSearch() {
    const searchInput = document.querySelector(".search-input")
    if (searchInput) {
      searchInput.focus()
      searchInput.select()
    }
  }

  async performSearch(query) {
    if (!query.trim()) return

    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`)
      const results = await response.json()

      this.displaySearchResults(results)
    } catch (error) {
      console.error("Search error:", error)
      this.showNotification("Search failed. Please try again.", "error")
    }
  }

  displaySearchResults(results) {
    // Implementation for displaying search results in a dropdown or modal
    console.log("Search results:", results)
  }

  // Product quick view
  async showProductQuickView(productId) {
    try {
      const response = await fetch(`/api/products/${productId}`)
      const product = await response.json()

      this.createQuickViewModal(product)
    } catch (error) {
      console.error("Error loading product:", error)
      this.showNotification("Failed to load product details", "error")
    }
  }

  createQuickViewModal(product) {
    const modal = document.createElement("div")
    modal.className = "quick-view-modal"
    modal.innerHTML = `
      <div class="modal-overlay" onclick="this.parentElement.remove()"></div>
      <div class="modal-content">
        <button class="modal-close" onclick="this.closest('.quick-view-modal').remove()">
          <i class="fas fa-times"></i>
        </button>
        <div class="product-quick-view">
          <div class="product-image">
            <img src="${product.image_url}" alt="${product.name}">
          </div>
          <div class="product-details">
            <span class="product-category">${product.category}</span>
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <div class="product-price">₹${product.price}</div>
            <div class="product-actions">
              <button class="add-to-cart-btn" onclick="amulApp.addToCart('${product.id}')">
                <i class="fas fa-shopping-cart"></i> Add to Cart
              </button>
              <button class="favorite-btn" data-product-id="${product.id}" onclick="amulApp.toggleFavorite('${product.id}')">
                <i class="far fa-heart"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `

    document.body.appendChild(modal)
    this.updateFavoriteButtons()
  }

  // News filtering
  setupNewsFiltering() {
    const categoryTags = document.querySelectorAll(".category-tag")
    categoryTags.forEach((tag) => {
      tag.addEventListener("click", (e) => {
        e.preventDefault()
        this.filterNews(tag.dataset.category)

        // Update active state
        categoryTags.forEach((t) => t.classList.remove("active"))
        tag.classList.add("active")
      })
    })
  }

  async filterNews(category) {
    try {
      const url = category === "all" ? "/api/news" : `/api/news?category=${category}`
      const response = await fetch(url)
      const newsItems = await response.json()

      this.updateNewsDisplay(newsItems)
    } catch (error) {
      console.error("Error filtering news:", error)
    }
  }

  updateNewsDisplay(newsItems) {
    const newsGrid = document.querySelector(".news-grid")
    if (!newsGrid) return

    newsGrid.innerHTML = newsItems
      .map(
        (item) => `
      <article class="news-card">
        <div class="news-image">
          <img src="${item.image_url}" alt="${item.title}">
          <span class="news-category-badge">${item.category}</span>
        </div>
        <div class="news-content">
          <h3>${item.title}</h3>
          <p>${item.content.substring(0, 150)}...</p>
          <div class="news-footer">
            <time>${new Date(item.published_at).toLocaleDateString()}</time>
            <button class="read-more-link" onclick="readFullArticle(${item.id})">
              Read More
            </button>
          </div>
        </div>
      </article>
    `,
      )
      .join("")
  }

  // Location search
  setupLocationSearch() {
    const searchBtn = document.querySelector(".search-location-btn")
    if (searchBtn) {
      searchBtn.addEventListener("click", () => this.searchLocations())
    }

    const locationInputs = document.querySelectorAll(".location-input")
    locationInputs.forEach((input) => {
      input.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          this.searchLocations()
        }
      })
    })
  }

  async searchLocations() {
    const cityInput = document.getElementById("citySearch")
    const stateInput = document.getElementById("stateSearch")

    const city = cityInput?.value.trim()
    const state = stateInput?.value.trim()

    if (!city && !state) {
      this.showNotification("Please enter a city or state to search", "warning")
      return
    }

    try {
      const params = new URLSearchParams()
      if (city) params.append("city", city)
      if (state) params.append("state", state)

      const response = await fetch(`/api/locations?${params}`)
      const locations = await response.json()

      this.updateLocationsDisplay(locations)
    } catch (error) {
      console.error("Error searching locations:", error)
      this.showNotification("Search failed. Please try again.", "error")
    }
  }

  updateLocationsDisplay(locations) {
    const locationsGrid = document.querySelector(".locations-grid")
    if (!locationsGrid) return

    if (locations.length === 0) {
      locationsGrid.innerHTML = `
        <div class="no-locations">
          <i class="fas fa-map-marker-alt"></i>
          <h3>No locations found</h3>
          <p>Try searching with different criteria.</p>
        </div>
      `
      return
    }

    locationsGrid.innerHTML = locations
      .map(
        (location) => `
      <div class="location-card">
        <div class="location-header">
          <h3>${location.name}</h3>
          <span class="location-type">${location.city}, ${location.state}</span>
        </div>
        <div class="location-details">
          <div class="detail-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>${location.address}</span>
          </div>
          ${
            location.phone
              ? `
            <div class="detail-item">
              <i class="fas fa-phone"></i>
              <a href="tel:${location.phone}">${location.phone}</a>
            </div>
          `
              : ""
          }
          ${
            location.email
              ? `
            <div class="detail-item">
              <i class="fas fa-envelope"></i>
              <a href="mailto:${location.email}">${location.email}</a>
            </div>
          `
              : ""
          }
        </div>
        <div class="location-actions">
          <button class="directions-btn" onclick="amulApp.getDirections('${location.address}')">
            <i class="fas fa-directions"></i> Get Directions
          </button>
        </div>
      </div>
    `,
      )
      .join("")
  }

  // Utility functions
  getDirections(address) {
    const encodedAddress = encodeURIComponent(address)
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`
    window.open(mapsUrl, "_blank")
  }

  handleNewsletterSubscription(event) {
    event.preventDefault()
    const form = event.target
    const email = form.querySelector('input[type="email"]').value

    if (this.validateEmail(email)) {
      // Simulate API call
      setTimeout(() => {
        this.showNotification("Thank you for subscribing to our newsletter!", "success")
        form.reset()
      }, 1000)
    } else {
      this.showNotification("Please enter a valid email address", "error")
    }
  }

  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  // Lazy loading for images
  setupLazyLoading() {
    const images = document.querySelectorAll("img[data-src]")

    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target
          img.src = img.dataset.src
          img.classList.remove("lazy")
          observer.unobserve(img)
        }
      })
    })

    images.forEach((img) => imageObserver.observe(img))
  }

  // Scroll animations
  setupScrollAnimations() {
    const animatedElements = document.querySelectorAll(".animate-on-scroll")

    const scrollObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animated")
          }
        })
      },
      { threshold: 0.1 },
    )

    animatedElements.forEach((el) => scrollObserver.observe(el))
  }

  // Notification system
  showNotification(message, type = "info") {
    const notification = document.createElement("div")
    notification.className = `notification notification-${type}`

    const icon = {
      success: "fas fa-check-circle",
      error: "fas fa-exclamation-circle",
      warning: "fas fa-exclamation-triangle",
      info: "fas fa-info-circle",
    }[type]

    notification.innerHTML = `
      <i class="${icon}"></i>
      <span>${message}</span>
      <button class="notification-close" onclick="this.parentElement.remove()">
        <i class="fas fa-times"></i>
      </button>
    `

    // Style the notification
    Object.assign(notification.style, {
      position: "fixed",
      top: "20px",
      right: "20px",
      background: this.getNotificationColor(type),
      color: "white",
      padding: "15px 20px",
      borderRadius: "10px",
      boxShadow: "0 5px 25px rgba(0,0,0,0.2)",
      zIndex: "9999",
      display: "flex",
      alignItems: "center",
      gap: "10px",
      minWidth: "300px",
      animation: "slideInRight 0.3s ease-out",
    })

    document.body.appendChild(notification)

    // Auto remove after 5 seconds
    setTimeout(() => {
      if (notification.parentElement) {
        notification.style.animation = "slideOutRight 0.3s ease-in"
        setTimeout(() => notification.remove(), 300)
      }
    }, 5000)
  }

  getNotificationColor(type) {
    const colors = {
      success: "#28a745",
      error: "#dc3545",
      warning: "#ffc107",
      info: "#007bff",
    }
    return colors[type] || colors.info
  }
}

// Global functions for backward compatibility
function addToCart(productId, quantity = 1) {
  amulApp.addToCart(productId, quantity)
}

function filterByCategory(category) {
  // This function is handled in products.js
  console.log("Filtering by category:", category)
}

function readFullArticle(articleId) {
  window.location.href = `/news/${articleId}`
}

function getDirections(address) {
  amulApp.getDirections(address)
}

function searchLocations() {
  amulApp.searchLocations()
}

function filterNews(category) {
  amulApp.filterNews(category)
}

// Initialize the app
let amulApp
document.addEventListener("DOMContentLoaded", () => {
  amulApp = new AmulApp()
})
