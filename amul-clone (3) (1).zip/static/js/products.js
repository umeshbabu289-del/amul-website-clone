// Products page JavaScript functionality

// Filter products by category
function filterByCategory(category) {
  const products = document.querySelectorAll(".product-card")
  const filterBtns = document.querySelectorAll(".filter-btn")

  // Update active filter button
  filterBtns.forEach((btn) => btn.classList.remove("active"))
  event.target.classList.add("active")

  // Show/hide products
  products.forEach((product) => {
    if (category === "all" || product.dataset.category === category) {
      product.style.display = "block"
      product.style.animation = "fadeIn 0.5s ease-in"
    } else {
      product.style.display = "none"
    }
  })

  // Update URL without page reload
  const url = new URL(window.location)
  if (category === "all") {
    url.searchParams.delete("category")
  } else {
    url.searchParams.set("category", category)
  }
  window.history.pushState({}, "", url)
}

// Add to cart functionality
function addToCart(productId) {
  // Get product details
  const productCard = document.querySelector(`[data-product-id="${productId}"]`)

  if (!productCard) {
    console.error("Product not found:", productId)
    return
  }

  // Add to cart logic (localStorage for demo)
  const cart = JSON.parse(localStorage.getItem("amul_cart") || "[]")

  // Check if product already in cart
  const existingItem = cart.find((item) => item.id === productId)

  if (existingItem) {
    existingItem.quantity += 1
  } else {
    cart.push({
      id: productId,
      quantity: 1,
      timestamp: new Date().toISOString(),
    })
  }

  localStorage.setItem("amul_cart", JSON.stringify(cart))

  // Show success message
  showNotification("Product added to cart!", "success")

  // Update cart counter if exists
  updateCartCounter()
}

// Show notification
function showNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.textContent = message

  // Style the notification
  Object.assign(notification.style, {
    position: "fixed",
    top: "20px",
    right: "20px",
    background: type === "success" ? "#28a745" : "#007bff",
    color: "white",
    padding: "15px 25px",
    borderRadius: "25px",
    zIndex: "9999",
    animation: "slideInRight 0.3s ease-out",
  })

  document.body.appendChild(notification)

  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.animation = "slideOutRight 0.3s ease-in"
    setTimeout(() => notification.remove(), 300)
  }, 3000)
}

// Update cart counter
function updateCartCounter() {
  const cart = JSON.parse(localStorage.getItem("amul_cart") || "[]")
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)

  const cartCounter = document.querySelector(".cart-counter")
  if (cartCounter) {
    cartCounter.textContent = totalItems
    cartCounter.style.display = totalItems > 0 ? "block" : "none"
  }
}

// Search products
function searchProducts(query) {
  const products = document.querySelectorAll(".product-card")
  const searchTerm = query.toLowerCase()

  products.forEach((product) => {
    const name = product.querySelector(".product-name").textContent.toLowerCase()
    const description = product.querySelector(".product-description").textContent.toLowerCase()
    const category = product.dataset.category.toLowerCase()

    if (name.includes(searchTerm) || description.includes(searchTerm) || category.includes(searchTerm)) {
      product.style.display = "block"
    } else {
      product.style.display = "none"
    }
  })
}

// Initialize products page
document.addEventListener("DOMContentLoaded", () => {
  // Update cart counter on page load
  updateCartCounter()

  // Handle URL parameters
  const urlParams = new URLSearchParams(window.location.search)
  const category = urlParams.get("category")

  if (category) {
    const filterBtn = document.querySelector(`[onclick="filterByCategory('${category}')"]`)
    if (filterBtn) {
      filterBtn.click()
    }
  }

  // Add search functionality to existing search box
  const searchInput = document.querySelector(".search-input")
  if (searchInput) {
    let searchTimeout
    searchInput.addEventListener("input", (e) => {
      clearTimeout(searchTimeout)
      searchTimeout = setTimeout(() => {
        searchProducts(e.target.value)
      }, 300)
    })
  }
})

// Add CSS animations
const style = document.createElement("style")
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
  }
`
document.head.appendChild(style)
