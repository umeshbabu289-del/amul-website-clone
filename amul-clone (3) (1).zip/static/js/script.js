// Amul Clone JavaScript

document.addEventListener("DOMContentLoaded", () => {
  // Hero slider functionality
  initHeroSlider()

  // Search functionality
  initSearch()

  // Mobile menu toggle
  initMobileMenu()

  // Video play functionality
  initVideoPlayer()

  // Smooth scrolling for anchor links
  initSmoothScrolling()
})

function initHeroSlider() {
  const slides = document.querySelectorAll(".slide")
  let currentSlide = 0

  if (slides.length > 1) {
    setInterval(() => {
      slides[currentSlide].classList.remove("active")
      currentSlide = (currentSlide + 1) % slides.length
      slides[currentSlide].classList.add("active")
    }, 5000)
  }
}

function initSearch() {
  const searchInput = document.querySelector(".search-input")
  const searchBtn = document.querySelector(".search-btn")

  if (searchInput && searchBtn) {
    searchBtn.addEventListener("click", () => {
      const query = searchInput.value.trim()
      if (query) {
        // Implement search functionality
        console.log("Searching for:", query)
        // You can redirect to a search results page or implement AJAX search
        window.location.href = `/search?q=${encodeURIComponent(query)}`
      }
    })

    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        searchBtn.click()
      }
    })
  }
}

function initMobileMenu() {
  // Add mobile menu toggle functionality
  const navbar = document.querySelector(".navbar")
  const navMenu = document.querySelector(".nav-menu")

  // Create mobile menu button
  const mobileMenuBtn = document.createElement("button")
  mobileMenuBtn.className = "mobile-menu-btn"
  mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>'
  mobileMenuBtn.style.display = "none"

  navbar.insertBefore(mobileMenuBtn, navMenu)

  mobileMenuBtn.addEventListener("click", () => {
    navMenu.classList.toggle("mobile-active")
  })

  // Show/hide mobile menu button based on screen size
  function checkScreenSize() {
    if (window.innerWidth <= 768) {
      mobileMenuBtn.style.display = "block"
    } else {
      mobileMenuBtn.style.display = "none"
      navMenu.classList.remove("mobile-active")
    }
  }

  window.addEventListener("resize", checkScreenSize)
  checkScreenSize()
}

function initVideoPlayer() {
  const videoThumbnails = document.querySelectorAll(".video-thumbnail")

  videoThumbnails.forEach((thumbnail) => {
    thumbnail.addEventListener("click", () => {
      // Implement video player functionality
      console.log("Playing video...")
      // You can integrate with YouTube API or other video services
      alert("Video player would open here")
    })
  })
}

function initSmoothScrolling() {
  const links = document.querySelectorAll('a[href^="#"]')

  links.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href")
      const targetElement = document.querySelector(targetId)

      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: "smooth",
        })
      }
    })
  })
}

// Contact form functionality
function submitContactForm(event) {
  event.preventDefault()

  const formData = new FormData(event.target)
  const data = Object.fromEntries(formData)

  fetch("/contact", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((result) => {
      if (result.success) {
        alert(result.message)
        event.target.reset()
      } else {
        alert("Error submitting form. Please try again.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Error submitting form. Please try again.")
    })
}

// Product filtering functionality
function filterProducts(category) {
  const products = document.querySelectorAll(".product-card")

  products.forEach((product) => {
    if (category === "all" || product.dataset.category === category) {
      product.style.display = "block"
    } else {
      product.style.display = "none"
    }
  })
}

// Add to cart functionality (placeholder)
function addToCart(productId) {
  console.log("Adding product to cart:", productId)
  alert("Product added to cart!")
}

// Newsletter subscription
function subscribeNewsletter(email) {
  if (email && email.includes("@")) {
    console.log("Subscribing email:", email)
    alert("Thank you for subscribing to our newsletter!")
    return true
  } else {
    alert("Please enter a valid email address.")
    return false
  }
}
