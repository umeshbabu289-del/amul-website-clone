from flask import Flask, render_template, request, jsonify, send_from_directory
import os
from datetime import datetime
from data_manager import DataManager
from api.routes import api

app = Flask(__name__)

# Initialize data manager
data_manager = DataManager()

# Static files route
@app.route('/images/<path:filename>')
def serve_images(filename):
    return send_from_directory('static/images', filename)

# Home page
@app.route('/')
def index():
    # Get featured products
    featured_products = data_manager.get_products(featured=True, limit=6)
    
    # Get latest news
    latest_news = data_manager.get_news(limit=4)
    
    # Get categories
    categories = data_manager.get_categories()
    
    return render_template('index.html', 
                         featured_products=featured_products,
                         latest_news=latest_news,
                         categories=categories)

# Products page
@app.route('/products')
@app.route('/products/<category>')
def products(category=None):
    if category:
        products = data_manager.get_products(category=category)
    else:
        products = data_manager.get_products()
    
    categories = data_manager.get_categories()
    
    return render_template('products.html', 
                         products=products, 
                         categories=categories,
                         current_category=category)

# News page
@app.route('/news')
def news():
    news_items = data_manager.get_news()
    
    return render_template('news.html', news_items=news_items)

# Locations page
@app.route('/locations')
def locations():
    locations = data_manager.get_locations()
    
    return render_template('locations.html', locations=locations)

# Contact page
@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        inquiry_data = {
            'name': request.form['name'],
            'email': request.form['email'],
            'phone': request.form.get('phone', ''),
            'subject': request.form.get('subject', ''),
            'message': request.form['message']
        }
        
        data_manager.create_contact_inquiry(inquiry_data)
        
        return jsonify({'success': True, 'message': 'Thank you for your inquiry!'})
    
    return render_template('contact.html')

# Search route for frontend
@app.route('/search')
def search_page():
    query = request.args.get('q', '')
    
    if not query:
        return render_template('search.html', query='', results=None)
    
    results = data_manager.search(query)
    
    return render_template('search.html', query=query, results=results)

# API endpoints
@app.route('/api/products')
def api_products():
    products = data_manager.get_products()
    return jsonify(products)

@app.route('/api/news')
def api_news():
    news_items = data_manager.get_news()
    return jsonify(news_items)

# Register API blueprint with data manager
api.data_manager = data_manager
app.register_blueprint(api)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
