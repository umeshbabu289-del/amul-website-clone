import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional

class DataManager:
    """JSON-based data management system to replace SQL database"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        self.ensure_data_directory()
        self.initialize_data_files()
    
    def ensure_data_directory(self):
        """Create data directory if it doesn't exist"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
    
    def get_file_path(self, filename: str) -> str:
        """Get full path for data file"""
        return os.path.join(self.data_dir, f"{filename}.json")
    
    def load_data(self, filename: str) -> List[Dict]:
        """Load data from JSON file"""
        file_path = self.get_file_path(filename)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def save_data(self, filename: str, data: List[Dict]):
        """Save data to JSON file"""
        file_path = self.get_file_path(filename)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    
    def get_next_id(self, data: List[Dict]) -> int:
        """Get next available ID"""
        if not data:
            return 1
        return max(item.get('id', 0) for item in data) + 1
    
    def initialize_data_files(self):
        """Initialize data files with sample data if they don't exist"""
        
        # Initialize categories
        if not os.path.exists(self.get_file_path('categories')):
            categories = [
                {"id": 1, "name": "Milk", "slug": "milk", "display_order": 1, "description": "Fresh dairy milk products"},
                {"id": 2, "name": "Butter", "slug": "butter", "display_order": 2, "description": "Premium butter varieties"},
                {"id": 3, "name": "Cheese", "slug": "cheese", "display_order": 3, "description": "Delicious cheese products"},
                {"id": 4, "name": "Ice Cream", "slug": "ice-cream", "display_order": 4, "description": "Creamy ice cream flavors"},
                {"id": 5, "name": "Yogurt", "slug": "yogurt", "display_order": 5, "description": "Healthy yogurt options"},
                {"id": 6, "name": "Ghee", "slug": "ghee", "display_order": 6, "description": "Pure clarified butter"}
            ]
            self.save_data('categories', categories)
        
        # Initialize products
        if not os.path.exists(self.get_file_path('products')):
            products = [
                {
                    "id": 1, "name": "Amul Gold Milk", "category": "milk", 
                    "description": "Premium full cream milk with rich taste and nutrition",
                    "price": 28.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                },
                {
                    "id": 2, "name": "Amul Butter", "category": "butter",
                    "description": "The taste of India - fresh and creamy butter",
                    "price": 52.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                },
                {
                    "id": 3, "name": "Amul Cheese Cubes", "category": "cheese",
                    "description": "Processed cheese cubes perfect for cooking and snacking",
                    "price": 45.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                },
                {
                    "id": 4, "name": "Amul Vanilla Ice Cream", "category": "ice-cream",
                    "description": "Rich and creamy vanilla ice cream made with pure milk",
                    "price": 85.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                },
                {
                    "id": 5, "name": "Amul Lassi", "category": "yogurt",
                    "description": "Traditional Indian yogurt drink with authentic taste",
                    "price": 15.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                },
                {
                    "id": 6, "name": "Amul Pure Ghee", "category": "ghee",
                    "description": "Pure cow ghee made from fresh cream",
                    "price": 520.0, "image_url": "/placeholder.svg?height=200&width=200",
                    "is_featured": True, "created_at": datetime.now().isoformat()
                }
            ]
            self.save_data('products', products)
        
        # Initialize news
        if not os.path.exists(self.get_file_path('news')):
            news = [
                {
                    "id": 1, "title": "Amul Celebrates 75 Years of Excellence",
                    "content": "Amul marks its 75th anniversary with special celebrations across India, honoring the cooperative movement that transformed dairy farming.",
                    "category": "company", "image_url": "/placeholder.svg?height=300&width=400",
                    "is_featured": True, "published_at": datetime.now().isoformat()
                },
                {
                    "id": 2, "title": "New Amul Ice Cream Flavors Launched",
                    "content": "Introducing exciting new flavors including Kulfi, Rajbhog, and Chocolate Brownie to our premium ice cream range.",
                    "category": "products", "image_url": "/placeholder.svg?height=300&width=400",
                    "is_featured": True, "published_at": datetime.now().isoformat()
                },
                {
                    "id": 3, "title": "Amul Supports Farmer Welfare Programs",
                    "content": "Continuing our commitment to farmer welfare with new initiatives for sustainable dairy farming and increased milk procurement prices.",
                    "category": "social", "image_url": "/placeholder.svg?height=300&width=400",
                    "is_featured": False, "published_at": datetime.now().isoformat()
                },
                {
                    "id": 4, "title": "Amul Goes Digital with New Mobile App",
                    "content": "Launch of the new Amul mobile app for easy ordering and delivery of fresh dairy products directly to your doorstep.",
                    "category": "technology", "image_url": "/placeholder.svg?height=300&width=400",
                    "is_featured": True, "published_at": datetime.now().isoformat()
                }
            ]
            self.save_data('news', news)
        
        # Initialize locations
        if not os.path.exists(self.get_file_path('locations')):
            locations = [
                {
                    "id": 1, "name": "Amul Dairy - Anand", "address": "Amul Dairy Road, Anand",
                    "city": "Anand", "state": "Gujarat", "pincode": "388001",
                    "phone": "+91-2692-260148", "email": "anand@amul.coop"
                },
                {
                    "id": 2, "name": "Amul Dairy - Mumbai", "address": "Kurla Industrial Estate, Mumbai",
                    "city": "Mumbai", "state": "Maharashtra", "pincode": "400070",
                    "phone": "+91-22-25261234", "email": "mumbai@amul.coop"
                },
                {
                    "id": 3, "name": "Amul Dairy - Delhi", "address": "Patparganj Industrial Area, Delhi",
                    "city": "Delhi", "state": "Delhi", "pincode": "110092",
                    "phone": "+91-11-22151234", "email": "delhi@amul.coop"
                },
                {
                    "id": 4, "name": "Amul Dairy - Bangalore", "address": "Whitefield Industrial Area, Bangalore",
                    "city": "Bangalore", "state": "Karnataka", "pincode": "560066",
                    "phone": "+91-80-28451234", "email": "bangalore@amul.coop"
                }
            ]
            self.save_data('locations', locations)
        
        # Initialize contact inquiries (empty initially)
        if not os.path.exists(self.get_file_path('contact_inquiries')):
            self.save_data('contact_inquiries', [])
    
    # Product methods
    def get_products(self, category: Optional[str] = None, featured: Optional[bool] = None, 
                    search: Optional[str] = None, limit: Optional[int] = None) -> List[Dict]:
        """Get products with optional filtering"""
        products = self.load_data('products')
        
        # Apply filters
        if category:
            products = [p for p in products if p.get('category') == category]
        
        if featured is not None:
            products = [p for p in products if p.get('is_featured') == featured]
        
        if search:
            search_lower = search.lower()
            products = [p for p in products if 
                       search_lower in p.get('name', '').lower() or 
                       search_lower in p.get('description', '').lower()]
        
        # Sort by name
        products.sort(key=lambda x: x.get('name', ''))
        
        # Apply limit
        if limit:
            products = products[:limit]
        
        return products
    
    def get_product_by_id(self, product_id: int) -> Optional[Dict]:
        """Get single product by ID"""
        products = self.load_data('products')
        return next((p for p in products if p.get('id') == product_id), None)
    
    def create_product(self, product_data: Dict) -> Dict:
        """Create new product"""
        products = self.load_data('products')
        
        new_product = {
            'id': self.get_next_id(products),
            'created_at': datetime.now().isoformat(),
            **product_data
        }
        
        products.append(new_product)
        self.save_data('products', products)
        
        return new_product
    
    # Category methods
    def get_categories(self) -> List[Dict]:
        """Get all categories"""
        categories = self.load_data('categories')
        return sorted(categories, key=lambda x: x.get('display_order', 0))
    
    # News methods
    def get_news(self, category: Optional[str] = None, featured: Optional[bool] = None,
                limit: Optional[int] = None) -> List[Dict]:
        """Get news with optional filtering"""
        news = self.load_data('news')
        
        # Apply filters
        if category:
            news = [n for n in news if n.get('category') == category]
        
        if featured is not None:
            news = [n for n in news if n.get('is_featured') == featured]
        
        # Sort by published date (newest first)
        news.sort(key=lambda x: x.get('published_at', ''), reverse=True)
        
        # Apply limit
        if limit:
            news = news[:limit]
        
        return news
    
    def get_news_by_id(self, news_id: int) -> Optional[Dict]:
        """Get single news item by ID"""
        news = self.load_data('news')
        return next((n for n in news if n.get('id') == news_id), None)
    
    # Location methods
    def get_locations(self, city: Optional[str] = None, state: Optional[str] = None) -> List[Dict]:
        """Get locations with optional filtering"""
        locations = self.load_data('locations')
        
        # Apply filters
        if city:
            city_lower = city.lower()
            locations = [l for l in locations if city_lower in l.get('city', '').lower()]
        
        if state:
            state_lower = state.lower()
            locations = [l for l in locations if state_lower in l.get('state', '').lower()]
        
        # Sort by state, then city
        locations.sort(key=lambda x: (x.get('state', ''), x.get('city', '')))
        
        return locations
    
    # Contact methods
    def create_contact_inquiry(self, inquiry_data: Dict) -> Dict:
        """Create new contact inquiry"""
        inquiries = self.load_data('contact_inquiries')
        
        new_inquiry = {
            'id': self.get_next_id(inquiries),
            'status': 'pending',
            'created_at': datetime.now().isoformat(),
            **inquiry_data
        }
        
        inquiries.append(new_inquiry)
        self.save_data('contact_inquiries', inquiries)
        
        return new_inquiry
    
    def get_contact_inquiries(self, status: Optional[str] = None, limit: int = 50) -> List[Dict]:
        """Get contact inquiries with optional filtering"""
        inquiries = self.load_data('contact_inquiries')
        
        # Apply filters
        if status:
            inquiries = [i for i in inquiries if i.get('status') == status]
        
        # Sort by created date (newest first)
        inquiries.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # Apply limit
        return inquiries[:limit]
    
    # Search methods
    def search(self, query: str, limit: int = 20) -> Dict:
        """Global search across products and news"""
        query_lower = query.lower()
        
        # Search products
        products = self.load_data('products')
        matching_products = []
        for product in products:
            if (query_lower in product.get('name', '').lower() or 
                query_lower in product.get('description', '').lower()):
                matching_products.append({
                    'type': 'product',
                    'id': product['id'],
                    'title': product['name'],
                    'description': product['description'],
                    'image_url': product.get('image_url'),
                    'price': product.get('price')
                })
        
        # Search news
        news = self.load_data('news')
        matching_news = []
        for item in news:
            if (query_lower in item.get('title', '').lower() or 
                query_lower in item.get('content', '').lower()):
                matching_news.append({
                    'type': 'news',
                    'id': item['id'],
                    'title': item['title'],
                    'description': item['content'],
                    'image_url': item.get('image_url'),
                    'published_at': item.get('published_at')
                })
        
        # Limit results
        matching_products = matching_products[:limit//2]
        matching_news = matching_news[:limit//2]
        
        return {
            'query': query,
            'products': matching_products,
            'news': matching_news,
            'total': len(matching_products) + len(matching_news)
        }
    
    # Statistics methods
    def get_stats(self) -> Dict:
        """Get website statistics"""
        products = self.load_data('products')
        news = self.load_data('news')
        locations = self.load_data('locations')
        inquiries = self.load_data('contact_inquiries')
        
        # Product statistics
        product_stats = {
            'total': len(products),
            'featured': len([p for p in products if p.get('is_featured')]),
            'by_category': {}
        }
        
        for product in products:
            category = product.get('category', 'unknown')
            product_stats['by_category'][category] = product_stats['by_category'].get(category, 0) + 1
        
        # News statistics
        news_stats = {
            'total': len(news),
            'featured': len([n for n in news if n.get('is_featured')])
        }
        
        # Location statistics
        location_stats = {
            'total': len(locations),
            'by_state': {}
        }
        
        for location in locations:
            state = location.get('state', 'unknown')
            location_stats['by_state'][state] = location_stats['by_state'].get(state, 0) + 1
        
        # Inquiry statistics
        inquiry_stats = {
            'total': len(inquiries),
            'pending': len([i for i in inquiries if i.get('status') == 'pending'])
        }
        
        return {
            'products': product_stats,
            'news': news_stats,
            'locations': location_stats,
            'inquiries': inquiry_stats
        }
