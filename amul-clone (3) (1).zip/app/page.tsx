"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, ShoppingCart, Menu, X, Star, MapPin, Phone, Mail } from "lucide-react"

// Mock data for the Amul website
const products = [
  { id: 1, name: "Amul Butter", price: "₹60", category: "Butter", image: "/amul-butter-pack.jpg", rating: 4.8 },
  { id: 2, name: "Amul Milk", price: "₹28", category: "Milk", image: "/amul-milk-packet.jpg", rating: 4.9 },
  { id: 3, name: "Amul Cheese", price: "₹120", category: "Cheese", image: "/amul-cheese-block.jpg", rating: 4.7 },
  {
    id: 4,
    name: "Amul Ice Cream",
    price: "₹45",
    category: "Ice Cream",
    image: "/amul-ice-cream-cup.jpg",
    rating: 4.6,
  },
  { id: 5, name: "Amul Lassi", price: "₹25", category: "Beverages", image: "/amul-lassi-bottle.jpg", rating: 4.5 },
  { id: 6, name: "Amul Paneer", price: "₹80", category: "Paneer", image: "/amul-paneer-pack.jpg", rating: 4.8 },
]

const news = [
  {
    id: 1,
    title: "Amul Celebrates 75 Years of Excellence",
    date: "2024-01-15",
    content: "Amul marks its 75th anniversary with special celebrations across India.",
  },
  {
    id: 2,
    title: "New Organic Product Line Launched",
    date: "2024-01-10",
    content: "Amul introduces a new range of organic dairy products.",
  },
  {
    id: 3,
    title: "Amul Wins Best Dairy Brand Award",
    date: "2024-01-05",
    content: "Amul receives recognition for quality and innovation in dairy industry.",
  },
]

const categories = ["All", "Milk", "Butter", "Cheese", "Ice Cream", "Beverages", "Paneer"]

export default function AmulHomepage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")
  const [cartItems, setCartItems] = useState(0)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(0)

  const heroSlides = [
    {
      title: "The Taste of India",
      subtitle: "Pure, Fresh & Nutritious Dairy Products",
      image: "/amul-dairy-farm-with-cows.jpg",
      cta: "Explore Products",
    },
    {
      title: "Amul - Utterly Butterly Delicious",
      subtitle: "Made from the finest milk",
      image: "/amul-butter-on-bread.jpg",
      cta: "Shop Now",
    },
    {
      title: "Quality You Can Trust",
      subtitle: "75+ Years of Excellence",
      image: "/amul-products-display.jpg",
      cta: "Learn More",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [heroSlides.length])

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const addToCart = () => {
    setCartItems((prev) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <img src="/amul-logo.jpg" alt="Amul Logo" className="h-10 w-10" />
              <span className="text-2xl font-bold text-blue-600">AMUL</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="#home" className="text-gray-700 hover:text-blue-600 font-medium">
                Home
              </a>
              <a href="#products" className="text-gray-700 hover:text-blue-600 font-medium">
                Products
              </a>
              <a href="#about" className="text-gray-700 hover:text-blue-600 font-medium">
                About Us
              </a>
              <a href="#news" className="text-gray-700 hover:text-blue-600 font-medium">
                News
              </a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 font-medium">
                Contact
              </a>
            </nav>

            {/* Search and Cart */}
            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <Button variant="outline" size="sm" className="relative bg-transparent">
                <ShoppingCart className="h-4 w-4" />
                {cartItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {cartItems}
                  </Badge>
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              <nav className="flex flex-col space-y-2">
                <a href="#home" className="text-gray-700 hover:text-blue-600 font-medium py-2">
                  Home
                </a>
                <a href="#products" className="text-gray-700 hover:text-blue-600 font-medium py-2">
                  Products
                </a>
                <a href="#about" className="text-gray-700 hover:text-blue-600 font-medium py-2">
                  About Us
                </a>
                <a href="#news" className="text-gray-700 hover:text-blue-600 font-medium py-2">
                  News
                </a>
                <a href="#contact" className="text-gray-700 hover:text-blue-600 font-medium py-2">
                  Contact
                </a>
              </nav>
              <div className="mt-4 sm:hidden">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-96 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800">
          <img
            src={heroSlides[currentSlide].image || "/placeholder.svg"}
            alt="Hero"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">{heroSlides[currentSlide].title}</h1>
            <p className="text-xl md:text-2xl mb-8 text-pretty">{heroSlides[currentSlide].subtitle}</p>
            <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold">
              {heroSlides[currentSlide].cta}
            </Button>
          </div>
        </div>

        {/* Slide indicators */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full ${index === currentSlide ? "bg-white" : "bg-white/50"}`}
            />
          ))}
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Our Products</h2>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className="mb-2"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-2xl font-bold text-blue-600">{product.price}</span>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="ml-1 text-sm text-gray-600">{product.rating}</span>
                    </div>
                  </div>
                  <Button onClick={addToCart} className="w-full bg-blue-600 hover:bg-blue-700">
                    Add to Cart
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">About Amul</h2>
              <p className="text-lg text-gray-600 mb-6 text-pretty">
                Amul is India's largest food brand and its leading dairy brand. It is a brand managed by a cooperative
                body, the Gujarat Co-operative Milk Marketing Federation Ltd. (GCMMF), which today is jointly owned by
                36 lakh milk producers in Gujarat.
              </p>
              <p className="text-lg text-gray-600 mb-8 text-pretty">
                With over 75 years of experience, Amul has been providing pure, fresh, and nutritious dairy products to
                millions of families across India and beyond.
              </p>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Learn More
              </Button>
            </div>
            <div className="relative">
              <img src="/amul-dairy-cooperative-farmers.jpg" alt="Amul Story" className="rounded-lg shadow-lg" />
            </div>
          </div>
        </div>
      </section>

      {/* News Section */}
      <section id="news" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Latest News</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {news.map((item) => (
              <Card key={item.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="text-sm text-blue-600 mb-2">{item.date}</div>
                  <h3 className="font-semibold text-lg mb-3 text-balance">{item.title}</h3>
                  <p className="text-gray-600 text-pretty">{item.content}</p>
                  <Button variant="link" className="p-0 mt-3 text-blue-600">
                    Read More →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Contact Us</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold mb-6">Get in Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-blue-600 mr-3" />
                  <span>Amul Dairy, Anand, Gujarat, India</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-blue-600 mr-3" />
                  <span>+91 2692 258506</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-blue-600 mr-3" />
                  <span>info@amul.coop</span>
                </div>
              </div>
            </div>
            <div>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <textarea
                  placeholder="Your Message"
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                ></textarea>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Send Message</Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-blue-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img src="/amul-logo-white.jpg" alt="Amul Logo" className="h-8 w-8" />
                <span className="text-xl font-bold">AMUL</span>
              </div>
              <p className="text-blue-200 text-pretty">
                India's largest food brand providing pure, fresh, and nutritious dairy products.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Products</h4>
              <ul className="space-y-2 text-blue-200">
                <li>
                  <a href="#" className="hover:text-white">
                    Milk
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Butter
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Cheese
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Ice Cream
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-blue-200">
                <li>
                  <a href="#" className="hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    News
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-blue-200 hover:text-white">
                  Facebook
                </Button>
                <Button variant="ghost" size="sm" className="text-blue-200 hover:text-white">
                  Twitter
                </Button>
                <Button variant="ghost" size="sm" className="text-blue-200 hover:text-white">
                  Instagram
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-blue-700 mt-8 pt-8 text-center text-blue-200">
            <p>&copy; 2025 Amul. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
