from flask import Blueprint, request, jsonify
from datetime import datetime

# Create API blueprint
api = Blueprint('api', __name__, url_prefix='/api')

# Data manager will be injected from main app
data_manager = None

# Products API endpoints
@api.route('/products', methods=['GET'])
def get_products():
    """Get all products with optional filtering"""
    try:
        # Get query parameters
        category = request.args.get('category')
        featured = request.args.get('featured')
        search = request.args.get('search')
        limit = request.args.get('limit', type=int)
        
        # Convert featured to boolean
        featured_bool = None
        if featured:
            featured_bool = featured.lower() == 'true'
        
        products = data_manager.get_products(
            category=category,
            featured=featured_bool,
            search=search,
            limit=limit
        )
        
        return jsonify(products)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get single product by ID"""
    try:
        product = data_manager.get_product_by_id(product_id)
        
        if product:
            return jsonify(product)
        else:
            return jsonify({'error': 'Product not found'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/products', methods=['POST'])
def create_product():
    """Create new product (admin only)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'category', 'description', 'price']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        product = data_manager.create_product(data)
        
        return jsonify({'id': product['id'], 'message': 'Product created successfully'}), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Categories API endpoints
@api.route('/categories', methods=['GET'])
def get_categories():
    """Get all product categories"""
    try:
        categories = data_manager.get_categories()
        return jsonify(categories)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# News API endpoints
@api.route('/news', methods=['GET'])
def get_news():
    """Get all news with optional filtering"""
    try:
        # Get query parameters
        category = request.args.get('category')
        featured = request.args.get('featured')
        limit = request.args.get('limit', type=int)
        
        # Convert featured to boolean
        featured_bool = None
        if featured:
            featured_bool = featured.lower() == 'true'
        
        news_items = data_manager.get_news(
            category=category,
            featured=featured_bool,
            limit=limit
        )
        
        return jsonify(news_items)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/news/<int:news_id>', methods=['GET'])
def get_news_item(news_id):
    """Get single news item by ID"""
    try:
        news_item = data_manager.get_news_by_id(news_id)
        
        if news_item:
            return jsonify(news_item)
        else:
            return jsonify({'error': 'News item not found'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Locations API endpoints
@api.route('/locations', methods=['GET'])
def get_locations():
    """Get all locations with optional filtering"""
    try:
        # Get query parameters
        city = request.args.get('city')
        state = request.args.get('state')
        
        locations = data_manager.get_locations(city=city, state=state)
        
        return jsonify(locations)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Contact API endpoints
@api.route('/contact', methods=['POST'])
def submit_contact():
    """Submit contact form"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'message']
        for field in required_fields:
            if field not in data or not data[field].strip():
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        inquiry_data = {
            'name': data['name'].strip(),
            'email': data['email'].strip(),
            'phone': data.get('phone', '').strip(),
            'subject': data.get('subject', '').strip(),
            'message': data['message'].strip()
        }
        
        inquiry = data_manager.create_contact_inquiry(inquiry_data)
        
        return jsonify({
            'id': inquiry['id'],
            'message': 'Thank you for your inquiry! We will get back to you soon.'
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api.route('/contact', methods=['GET'])
def get_contact_inquiries():
    """Get all contact inquiries (admin only)"""
    try:
        # Get query parameters
        status = request.args.get('status')
        limit = request.args.get('limit', type=int, default=50)
        
        inquiries = data_manager.get_contact_inquiries(status=status, limit=limit)
        
        return jsonify(inquiries)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Search API endpoint
@api.route('/search', methods=['GET'])
def search():
    """Global search across products and news"""
    try:
        query = request.args.get('q', '').strip()
        if not query:
            return jsonify({'error': 'Search query is required'}), 400
        
        results = data_manager.search(query)
        
        return jsonify(results)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Statistics API endpoint
@api.route('/stats', methods=['GET'])
def get_stats():
    """Get website statistics"""
    try:
        stats = data_manager.get_stats()
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Health check endpoint
@api.route('/health', methods=['GET'])
def health_check():
    """API health check"""
    try:
        # Simple health check - verify data manager is working
        data_manager.get_categories()
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'storage': 'json_files'
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'timestamp': datetime.now().isoformat(),
            'error': str(e)
        }), 500
